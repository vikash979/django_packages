from django.apps import AppConfig


class TinymceConfig(AppConfig):
    name = 'tinymce'
